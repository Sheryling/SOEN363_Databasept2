import pandas as pd

tables = {}
malformed = {}
extra_lines = []

# Handles lines with too many values
def save_bad_line(bad_line):
    extra_lines.append({"file": key, "line": "|".join(bad_line)})
    return None

# ======================= SOURCE A =======================

files_A = ["ADMISSIONS.txt", "CLINICAL_NOTES.txt", "DIAG_ORDERS.txt", "DIAGNOSES.txt", "DISCHARGES.txt", "ICD9_DICT.txt",
           "ICU_RECORDS.txt", "LAB_EXAMS.txt", "PATIENTS.txt", "RAD_EXAMS.txt", "RAD_REPORTS.txt", "STAFF.txt",
           "SURGERIES.txt", "TRIAGE.txt", "UNIT_STAYS.txt", "UNITS.txt", "WARD_RECORDS.txt"]

for file in files_A:
    key = "A_" + file.replace(".txt", "")
    df = pd.read_csv("source_A_north_america/" + file, sep="|", on_bad_lines=save_bad_line, keep_default_na=False, engine="python")

    # Cutoff lines (lines with empty/missing cells)
    broken = df[df.isna().any(axis=1)]
    if len(broken) > 0:
        malformed[key] = broken
        df = df.dropna()

    tables[key] = df

# ======================= SOURCE B =======================

files_B = ["critical_care_obs.csv", "diagnoses.csv", "discharges.csv", "episodes.csv", "icd9_codes.csv", "imaging_reports.csv",
           "imaging.csv", "investigations.csv", "notes.csv", "operations.csv", "orders.csv", "patients.csv",
           "staff.csv", "triage.csv", "ward_obs.csv", "ward_stays.csv", "wards.csv"]

for file in files_B:
    key = "B_" + file.replace(".csv", "")
    df = pd.read_csv("source_B_europe/" + file, sep=";", on_bad_lines=save_bad_line, keep_default_na=False, engine="python")

    broken = df[df.isna().any(axis=1)]
    if len(broken) > 0:
        malformed[key] = broken
        df = df.dropna()

    tables[key] = df

# ======================= SOURCE C =======================
# One XML file. Each tag below is one entity; read_xml finds every element with that tag,
# at any depth in the tree, and makes one row per element.

tags_C = ["staff", "ward", "icdEntry", "patient", "admission", "triage", "diagnosis",
          "note", "surgery", "discharge", "order", "labExam", "imaging", "report",
          "wardStay", "ccRecord", "wardRound"]

for tag in tags_C:
    key = "C_" + tag
    df = pd.read_xml("source_C_asia/sakura_bay_export.xml", xpath=".//" + tag, parser="etree")

    # Records with no usable ID (missing, or not a number)
    # Ward codes (W01) and ICD-9 codes (V58.11) are not numbers on purpose, so they are only checked for missing
    id_col = df.columns[0]
    if tag in ["ward", "icdEntry"]:
        broken = df[df[id_col].isna()]
    else:
        broken = df[pd.to_numeric(df[id_col], errors="coerce").isna()]

    if len(broken) > 0:
        malformed[key] = broken
        df = df.drop(broken.index)

    tables[key] = df

# ======================= SOURCE D =======================
# One JSON file. Top level: staff, units, icd9Dictionary, patients.
# patients -> encounters -> triage, diagnoses, notes, procedures, discharge, orders, movements, wardRounds
#                           orders -> imaging (-> report), labResults
#                           movements -> criticalCareObservations
# Child records don't store their parent's ID (it's implied by nesting), so we add it as a column.

data = pd.read_json("source_D_africa/highveld_export.json", typ="series")

# One empty list per entity; rows get added as we walk through the file
rows_D = {"staff": [], "units": [], "icd9Dictionary": [], "patients": [], "encounters": [],
          "triage": [], "diagnoses": [], "notes": [], "procedures": [], "discharge": [],
          "orders": [], "imaging": [], "report": [], "labResults": [], "movements": [],
          "criticalCareObservations": [], "wardRounds": []}
bad_D = {"patients": [], "encounters": []}

# Adds one record to an entity's list: keeps its own fields, skips its child lists,
# and adds the parent's ID as an extra column
def add_row(entity, record, parent_col=None, parent_id=None):
    row = {}
    for field, value in record.items():
        if field in rows_D:          # a child entity (e.g. "triage" inside an encounter) -> its own table
            continue
        row[field] = value
    if parent_col is not None:
        row[parent_col] = parent_id
    rows_D[entity].append(row)

for record in data["staff"]:
    add_row("staff", record)
for record in data["units"]:
    add_row("units", record)
for record in data["icd9Dictionary"]:
    add_row("icd9Dictionary", record)

for p in data["patients"]:
    # Malformed: not a record (e.g. a piece of text), or no patient ID
    if not isinstance(p, dict) or p.get("patientRef") in (None, "", "unknown"):
        bad_D["patients"].append(str(p))
        continue
    add_row("patients", p)
    pid = p["patientRef"]

    for e in p.get("encounters", []):
        if not isinstance(e, dict):
            bad_D["encounters"].append(str(e) + "  (inside patientRef " + str(pid) + ")")
            continue
        add_row("encounters", e, "patientRef", pid)
        eid = e.get("encounterId")

        for child in ["triage", "diagnoses", "notes", "procedures", "wardRounds"]:
            for c in e.get(child, []):
                add_row(child, c, "encounterId", eid)
        if "discharge" in e:
            add_row("discharge", e["discharge"], "encounterId", eid)

        for o in e.get("orders", []):
            add_row("orders", o, "encounterId", eid)
            for im in o.get("imaging", []):
                add_row("imaging", im, "orderId", o.get("orderId"))
                if "report" in im:
                    add_row("report", im["report"], "examId", im.get("examId"))
            for lab in o.get("labResults", []):
                add_row("labResults", lab, "orderId", o.get("orderId"))

        for m in e.get("movements", []):
            add_row("movements", m, "encounterId", eid)
            for cc in m.get("criticalCareObservations", []):
                add_row("criticalCareObservations", cc, "movementId", m.get("movementId"))

# Turn each list into a table (json_normalize also splits nested values like name -> name.first, name.last)
for entity in rows_D:
    key = "D_" + entity
    tables[key] = pd.json_normalize(rows_D[entity])

for entity in bad_D:
    if len(bad_D[entity]) > 0:
        malformed["D_" + entity] = pd.DataFrame({"entry": bad_D[entity]})

# ======================= CHECKS =======================

# Prints all tables and their sizes
for key in tables:
    print(key, tables[key].shape)

print("\nMalformed (removed from tables):")
for key in malformed:
    print(key, len(malformed[key]))

print("\nLines with too many values:", len(extra_lines))